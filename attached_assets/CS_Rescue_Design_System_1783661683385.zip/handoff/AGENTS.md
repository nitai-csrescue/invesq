# CS Rescue — Diagnostic Report Kit (for Claude on Replit)

This folder is a **self-contained brand kit** for generating on-brand **diagnostic PDFs**
(Revenue Durability Assessments, portfolio scorecards, executive briefs). Everything you
need to render a report is here — no external repo, no build step.

```
handoff/
├── AGENTS.md                       ← you are here
├── styles.css                      ← single entry point (import this one file)
├── tokens/
│   ├── colors.css                  ← brand + neutral + semantic + data-viz CSS vars
│   ├── typography.css              ← font families, weights, type scale vars
│   ├── spacing.css                 ← spacing scale, radii, shadows, easing
│   └── fonts.css                   ← Google-Fonts @import (needs internet)
├── assets/
│   ├── csrescue-wordmark.png       ← navy CS + orange RESCUE (canonical mark)
│   ├── csrescue-wordmark-white.png ← knockout for dark backgrounds
│   └── invesq-report-reference.png ← InvesQ Lifecycle Risk Report screenshot
└── diagnostic-report-template.html ← WORKING, print-ready reference report
```

## How to use it

1. **Link the stylesheet, once.** In any HTML report: `<link rel="stylesheet" href="styles.css">`.
   It `@import`s the four token files and the webfonts. Then style everything with the CSS
   variables it defines (`var(--navy-500)`, `var(--font-serif)`, `var(--radius-lg)`, …).
2. **Start from `diagnostic-report-template.html`.** It is a complete, on-brand report you can
   copy and edit — masthead, provocative lede + platform screenshot, the "Diligence Gap"
   two-column comparison, the Eight-Pillar framework strip, a **letter-graded scorecard**
   (A/B/C/F chips in brand severity colors), an engagement-deliverables grid, a leadership
   strip, and a navy CTA band. Swap the copy and data; keep the structure and classes.
3. **Fill it with real diagnostic data.** The scorecard rows and grade chips are the core
   output. Each row = one pillar; the `lv-*` class on the row drives both the chip color and
   the label:
   - `lv-optimized` → grade **A** → green → "Optimized"
   - `lv-functional` → grade **B** → blue → "Functional"
   - `lv-developing` → grade **C** → amber → "Developing"
   - `lv-critical` → grade **F** → red → "Critical"

## Generating the PDF

The template ships with a print stylesheet (`@page` + `@media print`), so any HTML→PDF path works.

**Chrome / Puppeteer / Playwright (recommended — highest fidelity):**
```js
const page = await browser.newPage();
await page.goto('file://' + absPath, { waitUntil: 'networkidle0' }); // waits for fonts
await page.pdf({ path: 'report.pdf', printBackground: true, preferCSSPageSize: true });
```
`printBackground: true` and `preferCSSPageSize: true` are required — without them the navy
panels and the `@page { size: 8.5in auto }` rule are ignored.

**WeasyPrint (Python, no browser):** `weasyprint diagnostic-report-template.html report.pdf`
— honors the same print CSS. Note WeasyPrint has weaker fl+grid support than Chrome; verify
the scorecard grid, and prefer the Chrome path for pixel fidelity.

**Fonts need internet.** `tokens/fonts.css` pulls Source Serif 4 / Public Sans / IBM Plex Mono
from Google Fonts. Replit has network access, so this works. For fully offline/deterministic
rendering, download the .woff2 files and replace the `@import` with local `@font-face` rules.

## Brand rules the report MUST follow

These are hard rules — a diagnostic report that breaks them is off-brand.

- **NO EM-DASHES.** Ever. Use periods, commas, or a middot (·). (Hyphens in "PE-backed",
  "day-1", "30/60/90-day" are fine.)
- **Two brand colors, used with discipline.** Navy `#1E3A5F` (`--navy-500`) is dominant:
  headers, rails, ink. Orange `#E8681A` (`--orange-500`) is the *single* highest-priority
  accent — one CTA, one standout marker, accent KPI figures. Never a large orange fill.
- **Typography roles are fixed:** Source Serif 4 = headlines / editorial (`--font-serif`);
  Public Sans = UI + body (`--font-ui`); IBM Plex Mono = metrics, scores, grades, labels
  (`--font-data`). Eyebrows are 10–12px, uppercase, letter-spacing ~0.14em, mono, muted or orange.
- **No emoji.** No check/cross marks. Use worded states + color ("Critical", "Developing",
  "Functional", "Optimized") and the `›` / `✦` / `→` glyphs.
- **Semantic colors** for health/severity only: success green `#16A34A`, warning amber
  `#F59E0B`, danger red `#DC2626`, info blue `#2563EB`.
- **Finance-grade tone.** Serious, institutional, evidence-forward — an investment memo, not a
  SaaS flyer. Every claim is time-bound and source-backed. Numbers are numerals, abbreviated
  for scale (`$1M+`, `98%`, `+10`).

## Audience & voice (for any copy you generate)

PE Operating Partners, Deal Partners, portfolio executives. Financially literate, time-poor,
skeptical. Declarative, benefit-first, "we" not "I". Use the operator's vocabulary precisely
(NRR, GRR, TTV, churn signals, IC-ready, value-creation thesis, holding period) without
over-explaining. The concept executives should remember: **Revenue Durability**.

---
*This kit is a curated extract of the full CS Rescue Design System. Fonts and the InvesQ logo
are open-source substitutions pending licensed/final assets — replace when available.*
